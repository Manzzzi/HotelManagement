package hotel1;
//customer class
public class Customer {
	String name;
	String mob;
	int room;
	String in_date;
	
	public Customer(String name, String mob, int room, String in_date) {  //constructor
		this.name = name;
		this.mob = mob;
		this.room = room;
		this.in_date = in_date;
	}
}
