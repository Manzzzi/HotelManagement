/*
MINI PROJECT
Topic:Hotel Management(Using hashtable)
Group members:2966 Vaishnavi Pande
              2948 Mansi Saptale



OUTPUT:

 *******************************************************************
-----------WELCOME TO SUNSHINE HOTEL- the lap of nature-----------
*******************************************************************

HOW WE CAN HELP YOU ?

PLEASE ENTER--
1. CHECK HOTEL DETAILS
2. BOOK A ROOM
3. CHECK OUT
4. CHECK GUEST LIST
1
----------FACILITIES AVAILABLE:----------
1.Car parking
2.24 Hour security
3.Total rooms=10
4.24 Hour Room service
5.laundry service
6.Swimming pool
7.Poolside dinner

=>ROOM DETAILS:
1.AC and Non-AC rooms Available
2.Delux room avilable with spa, jacuzzi and living room facilities.
Room Type    Price
AC           5000
Non-AC       3000
Delux        10,000

Check-in time:  14:00
Check-out time: 12:00

IF YOU WANT TO STAY ON PAGE ENTER ANY NUMBER AND 0 TO EXIT CODE!
2

PLEASE ENTER--
1. CHECK HOTEL DETAILS
2. BOOK A ROOM
3. CHECK OUT
4. CHECK GUEST LIST
2
Rooms are available, Please enter customer details to check in!
----------Enter customer details----------
Name:
Vaishnavi
Mobile number:
9308547762
Check in date:
14-12
Enter room no.
105
ROOM BOOKED! CHECK-IN SUCCESSFULL:)

IF YOU WANT TO STAY ON PAGE ENTER ANY NUMBER AND 0 TO EXIT CODE!
1

PLEASE ENTER--
1. CHECK HOTEL DETAILS
2. BOOK A ROOM
3. CHECK OUT
4. CHECK GUEST LIST
2
Rooms are available, Please enter customer details to check in!
----------Enter customer details----------
Name:
Naveen
Mobile number:
8557441269
Check in date:
4-12
Enter room no.
100
ROOM BOOKED! CHECK-IN SUCCESSFULL:)

IF YOU WANT TO STAY ON PAGE ENTER ANY NUMBER AND 0 TO EXIT CODE!
3

PLEASE ENTER--
1. CHECK HOTEL DETAILS
2. BOOK A ROOM
3. CHECK OUT
4. CHECK GUEST LIST
2
Rooms are available, Please enter customer details to check in!
----------Enter customer details----------
Name:
Sanjana
Mobile number:
7894561235
Check in date:
12-1
Enter room no.
100
This room is already booked! Enter another room no.
Enter room no.
200
ROOM BOOKED! CHECK-IN SUCCESSFULL:)

IF YOU WANT TO STAY ON PAGE ENTER ANY NUMBER AND 0 TO EXIT CODE!
3

PLEASE ENTER--
1. CHECK HOTEL DETAILS
2. BOOK A ROOM
3. CHECK OUT
4. CHECK GUEST LIST
2
Rooms are available, Please enter customer details to check in!
----------Enter customer details----------
Name:
Mansi
Mobile number:
7889665423
Check in date:
12-12
Enter room no.
109
ROOM BOOKED! CHECK-IN SUCCESSFULL:)

IF YOU WANT TO STAY ON PAGE ENTER ANY NUMBER AND 0 TO EXIT CODE!
2

PLEASE ENTER--
1. CHECK HOTEL DETAILS
2. BOOK A ROOM
3. CHECK OUT
4. CHECK GUEST LIST
2
Rooms are available, Please enter customer details to check in!
----------Enter customer details----------
Name:
Paridhi
Mobile number:
914563278
Check in date:
8-5
Enter room no.
119
ROOM BOOKED! CHECK-IN SUCCESSFULL:)

IF YOU WANT TO STAY ON PAGE ENTER ANY NUMBER AND 0 TO EXIT CODE!
2

PLEASE ENTER--
1. CHECK HOTEL DETAILS
2. BOOK A ROOM
3. CHECK OUT
4. CHECK GUEST LIST
4
----THESE DETAILS CAN ONLY BE VIEWED BY OWNER! YOU NEED OWNER LOGIN PASSWORD TO LOGIN----
PLEASE ENTER 1 TO LOGIN AND 0 TO EXIT
1
Please enter login password: 
1456
Your password is wrong! Do u want to try again (1 to login and 0 to exit):
1
Please enter login password: 
1234

----WELCOME SIR! HERE ARE YOUR CUSTOMERS CHECK-IN DETAILS----

------------------------------------------------------------------------
ROOM NO.            NAME      MOBILE NO.   CHECK-IN DATE
------------------------------------------------------------------------
    100          Naveen      8557441269      4-12
    200         Sanjana      7894561235      12-1
    119         Paridhi       914563278       8-5
      -               -               -         -
      -               -               -         -
    105       Vaishnavi      9308547762     14-12
      -               -               -         -
      -               -               -         -
      -               -               -         -
    109           Mansi      7889665423     12-12

IF YOU WANT TO STAY ON PAGE ENTER ANY NUMBER AND 0 TO EXIT CODE!
3

PLEASE ENTER--
1. CHECK HOTEL DETAILS
2. BOOK A ROOM
3. CHECK OUT
4. CHECK GUEST LIST
3
ENTER YOUR ROOM NO. PLEASE: 
115
# Room is empty! Please enter correct room no.#
ENTER YOUR ROOM NO. PLEASE: 
119
CHECK OUT SUCCESSSFUL!
DO VISIT AGAIN :)

IF YOU WANT TO STAY ON PAGE ENTER ANY NUMBER AND 0 TO EXIT CODE!
3

PLEASE ENTER--
1. CHECK HOTEL DETAILS
2. BOOK A ROOM
3. CHECK OUT
4. CHECK GUEST LIST
4
----THESE DETAILS CAN ONLY BE VIEWED BY OWNER! YOU NEED OWNER LOGIN PASSWORD TO LOGIN----
PLEASE ENTER 1 TO LOGIN AND 0 TO EXIT
1
Please enter login password: 
1234

----WELCOME SIR! HERE ARE YOUR CUSTOMERS CHECK-IN DETAILS----

------------------------------------------------------------------------
ROOM NO.            NAME      MOBILE NO.   CHECK-IN DATE
------------------------------------------------------------------------
    100          Naveen      8557441269      4-12
    200         Sanjana      7894561235      12-1
      -               -               -         -
      -               -               -         -
      -               -               -         -
    105       Vaishnavi      9308547762     14-12
      -               -               -         -
      -               -               -         -
      -               -               -         -
    109           Mansi      7889665423     12-12

IF YOU WANT TO STAY ON PAGE ENTER ANY NUMBER AND 0 TO EXIT CODE!
0
************* THANK YOU, VISIT AGAIN :)*****************

*/